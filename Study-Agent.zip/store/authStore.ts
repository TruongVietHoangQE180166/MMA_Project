import AsyncStorage from "@react-native-async-storage/async-storage";
import { create } from "zustand";
import { authApi, mockResetPassword } from "../services/mockApi";
import { AuthState } from "../types";

const initializeAuthState = async (): Promise<Partial<AuthState>> => {
  try {
    const token = await AsyncStorage.getItem("token");
    const userString = await AsyncStorage.getItem("user");
    if (token && userString) {
      const user = JSON.parse(userString);
      return {
        user,
        token,
        isAuthenticated: !!user && !!token,
      };
    }
    return {
      user: null,
      token: null,
      isAuthenticated: false,
    };
  } catch (error) {
    console.error("Failed to initialize auth state:", error);
    return {
      user: null,
      token: null,
      isAuthenticated: false,
    };
  }
};

export const useAuthStore = create<AuthState>((set) => ({
  user: null,
  token: null,
  isAuthenticated: false,

  login: async (email: string, password: string) => {
    try {
      const { user, token } = await authApi.login(email, password);
      await AsyncStorage.setItem("token", token);
      await AsyncStorage.setItem("user", JSON.stringify(user));

      set({ user, token, isAuthenticated: true });
    } catch (error: any) {
      throw new Error(error.message || "Invalid credentials");
    }
  },

  register: async (email: string, password: string, repassword: string) => {
    try {
      await authApi.register(email, password, repassword);
    } catch (error: any) {
      throw new Error(error.message || "Registration failed");
    }
  },

  logout: async () => {
    try {
      await AsyncStorage.removeItem("token");
      await AsyncStorage.removeItem("user");
      set({ user: null, token: null, isAuthenticated: false });
    } catch (error: any) {
      throw new Error(error.message || "Logout failed");
    }
  },

  resetPassword: async (email: string) => {
    await mockResetPassword(email);
  },
}));

initializeAuthState().then((initialState) => {
  useAuthStore.setState(initialState);
});
