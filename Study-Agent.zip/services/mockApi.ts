import { jwtDecode } from "jwt-decode";
import { User } from "../types";

const API_BASE_URL = "http://10.0.2.2:3000";

export const authApi = {
  login: async (
    email: string,
    password: string
  ): Promise<{ user: User; token: string }> => {
    if (!email || !password) {
      throw new Error("All fields are required");
    }

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 100000);

    try {
      const response = await fetch(`${API_BASE_URL}/auth/login`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ email, password }),
        signal: controller.signal,
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        try {
          const errorData = await response.json();
          
          // Khớp với server response format: {error: {message: "..."}}
          if (errorData.error && errorData.error.message) {
            throw new Error(errorData.error.message);
          }
          
          // Fallback cho các format khác
          if (errorData.message) {
            throw new Error(errorData.message);
          }
          
          // Generic fallback
          throw new Error("Login failed");
        } catch (parseError) {
          // Chỉ handle JSON parsing errors
          if (parseError instanceof SyntaxError) {
            throw new Error(`Server error: ${response.status} ${response.statusText}`);
          } else {
            // Re-throw error messages đã được xử lý ở trên
            throw parseError;
          }
        }
      }

      const { data } = await response.json();
      const { token } = data;

      const payload = jwtDecode<User>(token);
      if (!payload.email || !payload.role) {
        throw new Error("Invalid token payload");
      }

      return {
        user: { email: payload.email, role: payload.role },
        token,
      };
    } catch (error) {
      clearTimeout(timeoutId);

      if (error instanceof Error && error.name === "AbortError") {
        throw new Error("Request timed out");
      } else if (error instanceof TypeError) {
        throw new Error("Network error");
      } else if (error instanceof Error) {
        throw error;
      } else {
        throw new Error("An unknown error occurred during login");
      }
    }
  },

  register: async (
    email: string,
    password: string,
    repassword: string
  ): Promise<void> => {
    if (!email || !password || !repassword) {
      throw new Error("All fields are required");
    }
    if (password !== repassword) {
      throw new Error("Passwords do not match");
    }

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 10000);

    try {
      const response = await fetch(`${API_BASE_URL}/auth/register`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ email, password, repassword }),
        signal: controller.signal,
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        try {
          const errorData = await response.json();
          
          // Khớp với server response format: {error: {message: "..."}}
          if (errorData.error && errorData.error.message) {
            throw new Error(errorData.error.message);
          }
          
          // Fallback cho các format khác
          if (errorData.message) {
            throw new Error(errorData.message);
          }
          
          // Generic fallback
          throw new Error("Registration failed");
        } catch (parseError) {
          // Chỉ handle JSON parsing errors
          if (parseError instanceof SyntaxError) {
            throw new Error(`Server error: ${response.status} ${response.statusText}`);
          } else {
            // Re-throw error messages đã được xử lý ở trên
            throw parseError;
          }
        }
      }
    } catch (error) {
      clearTimeout(timeoutId);

      if (error instanceof Error && error.name === "AbortError") {
        throw new Error("Request timed out");
      } else if (error instanceof TypeError) {
        throw new Error("Network error");
      } else if (error instanceof Error) {
        throw error;
      } else {
        throw new Error("An unknown error occurred during registration");
      }
    }
  },
};

export const mockResetPassword = async (email: string): Promise<void> => {
  await new Promise((resolve) => setTimeout(resolve, 1000));
};